#include"student.h"
#include"working.h"
#include"nonworking.h"
int main()
{
	Student st("Angel",22,"HRD",11);
	Working wk("Sne",23,"capg","analyst");
	Nonworking nw("Liya",34,"12-5-2019");

	st.Display();
	wk.Display();
	nw.Display();
}
