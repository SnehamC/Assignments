#include"working.h"

Working::Working()
{
	cout<<"Working def const\n";
}
Working::Working(string n, int a,string org,string des):Person(n,a)
{
	cout<<"Working par const\n";
	orgname = org;
	designation = des;
}
void Working::setWorking()
{
	Person::setPerson();
	cout<<"Enter organisation name and designation: ";
        cin>>orgname>>designation;	
}
void Working::Display()
{
	Person::Display();
	cout<<"Working Details is: "<<orgname<<" "<<designation<<endl;
}
Working::~Working()
{
	cout<<"Work dest\n";
}


