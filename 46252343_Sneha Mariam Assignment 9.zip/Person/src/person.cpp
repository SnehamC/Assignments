#include "person.h"

Person::Person()
{
	cout<<"Person def const\n";
}
Person::Person(string n, int a)
{
	cout<<"Person par const\n";
	name = n;
	age = a;
}
void Person::setPerson()
{
	cout<<"Enter name and age: "<<endl;
	cin>>name>>age;
}
void Person::Display()
{
	cout<<"The person details are: "<<name<<" "<<age<<endl;
}
Person::~Person()
{
	cout<<"Person dest\n";
}

