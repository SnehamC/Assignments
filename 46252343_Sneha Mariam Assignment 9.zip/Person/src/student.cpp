#include"student.h"
Student::Student()
{
     cout<<"Student def const\n";
}

Student::Student(string n, int a, string in,int cl):Person(n,a)
{
	cout<<"Stud par const\n";
	inst = in;
	clas = cl;
}

void Student::setStudent()
{
	Person::setPerson();
	cout<<"Enter institute and class of student: ";
	cin>>inst>>clas;
}
void Student::Display()
{
	Person::Display();
	cout<<"Student information is: "<<inst<<" "<<clas<<endl;

}
Student::~Student()
{
	cout<<"Stud dest\n";
}
