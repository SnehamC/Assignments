#include"nonworking.h"

Nonworking::Nonworking()
{
	cout<<"Nonworking def const\n";
}
Nonworking::Nonworking(string n ,int a,string ndate):Person(n,a)
{
	cout<<"Nonworking par const\n";
	nondate =  ndate;
}
void Nonworking::setNonworking()
{
	Person::setPerson();
	cout<<"Enter date since not working: ";
	cin>>nondate;
}
void Nonworking::Display()
{
	Person::Display();
	cout<<"Nonworking details: "<<nondate<<endl;
}
Nonworking::~Nonworking()
{
	cout<<"Nonworking dest \n";
}
