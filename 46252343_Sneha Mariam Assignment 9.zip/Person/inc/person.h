#ifndef _PERSON_H
#pragma once
#include<iostream>
#include<cstring>
using namespace std;

class Person
{
	private:
		string name;
		int age;
	
	public:
	        Person();
	        Person(string,int);
	        void setPerson();
	        void Display();
	        ~Person();	
};
#endif
