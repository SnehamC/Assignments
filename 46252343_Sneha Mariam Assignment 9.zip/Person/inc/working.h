#ifndef _PERSON_H
#include"person.h"


class Working:public Person
{ 
	private:
		string orgname;
		string designation;
        public:
		Working();
		Working(string,int,string,string);
		void setWorking();
		void Display();
		~Working();
};
#endif













