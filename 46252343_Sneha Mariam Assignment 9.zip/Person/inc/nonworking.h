
#ifndef _PERSON_H
#include"person.h"
class Nonworking:public Person
{
	private:
		 string nondate;
	public:
		Nonworking();
		Nonworking(string,int,string);
		void setNonworking();
		void Display();
		~Nonworking();
};
#endif
